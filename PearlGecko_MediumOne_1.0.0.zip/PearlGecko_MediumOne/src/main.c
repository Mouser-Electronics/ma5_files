
#include "mqtt/MQTTClient.h"
#include "mqtt/MQTTConnect.h"
#include "wrapper/MQTTOsWrapper.h"
#include "em_chip.h"
#include "em_rtc.h"
#include "em_emu.h"
#include "rtcdriver.h"
#include "i2cspm.h"
#include "si7013.h"
#include "medium_one.h"

#define MQTT_PUBLISH_PERIOD         10000

#define INCLUDE_TEMP_HUMID			1

/* User LEDs on Pearl Gecko */
#define LED0_PORT	gpioPortF
#define LED0_PIN	4
#define LED1_PORT	gpioPortF
#define LED1_PIN	5

/* User Buttons on Pearl Gecko */
#define BTN0_PORT	gpioPortF
#define BTN0_PIN	6
#define BTN1_PORT	gpioPortF
#define BTN1_PIN	7

static RTCDRV_TimerID_t periodic_timer;
static MQTTClient client = DefaultClient;
static bool publish_now = false;
static unsigned iteration = 0;

#if defined(INCLUDE_TEMP_HUMID) && INCLUDE_TEMP_HUMID
I2CSPM_Init_TypeDef i2cInit = I2CSPM_INIT_DEFAULT;
#endif

static void publish();
static void timer_handler( RTCDRV_TimerID_t id, void *user);
#if 0
static void receive_handler(MessageData* rx_msg);
#endif
#if defined(INCLUDE_TEMP_HUMID) && INCLUDE_TEMP_HUMID
static void initTempHumid(void);
static void readTempHumid(uint32_t *rhData, int32_t *tData);
#endif

/******************************************************************************
 * @brief  Main
 *****************************************************************************/
int main(void)
{
    int ret;
    unsigned char send_buf[512];
    unsigned char recv_buf[2048];

    Network network;
    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;

    /* Chip errata */
    CHIP_Init();

    /* Initialize RTC timer. */
    RTCDRV_Init();
    RTCDRV_AllocateTimer(&periodic_timer);

    /* Initialize GPIO */
    CMU_ClockEnable(cmuClock_GPIO, true);

    GPIO_PinModeSet(LED0_PORT, LED0_PIN, gpioModePushPull, 0);
    GPIO_PinModeSet(LED1_PORT, LED1_PIN, gpioModePushPull, 0);
    GPIO_PinModeSet(BTN0_PORT, BTN0_PIN, gpioModeInput, 0);
    GPIO_PinModeSet(BTN1_PORT, BTN1_PIN, gpioModeInput, 0);

#if defined(INCLUDE_TEMP_HUMID) && INCLUDE_TEMP_HUMID
    /* Initialize temp & humid sensor */
    initTempHumid();
#endif

    data.MQTTVersion = 4;
    data.clientID.cstring = MQTT_CLIENT_ID;
    data.username.cstring = MQTT_USERNAME;
    data.password.cstring = MQTT_PASSWORD;

    NetworkInit(&network);
    RTCDRV_Delay(250);

    ret = NetworkConnect(&network, MQTT_BROKER, MQTT_PORT_NON_TLS);
    if (ret == FAILURE)
    {
        // error, return
        return ret;
    }
    RTCDRV_Delay(250);

    MQTTClientInit(&client, &network, 10000, send_buf, sizeof(send_buf), recv_buf, sizeof(recv_buf));
    RTCDRV_Delay(250);

    ret = MQTTConnect(&client, &data);
    if (ret != SUCCESS)
    {
        // error, return
        return ret;
    }
    RTCDRV_Delay(250);

#if 0
    MQTTSubscribe(&client, MQTT_SUB_TOPIC, QOS0, receive_handler);
    RTCDRV_Delay(250);
#endif

    // Start the timer that causes periodic message publishing

    RTCDRV_StartTimer(periodic_timer, rtcdrvTimerTypePeriodic, MQTT_PUBLISH_PERIOD, timer_handler, NULL);
    publish_now = true;

    while (true)
    {
        // can not execute UART blocking operations in timer handler,
        // so, we just set a flag and check it here in main app..
        if (publish_now == true) {

            publish_now = false;
            iteration++;

            publish();
        }

        MQTTYield(&client, 500);
    }

    // Won't reach here
#if 0
    MQTTUnsubscribe(&client, MQTT_SUB_TOPIC);
#endif
    MQTTDisconnect(&client);
    NetworkDisconnect(&network);

    return 0;
}

/******************************************************************************
 * @brief  Static functions
 *****************************************************************************/

static void publish()
{
    char buf[256];
    uint32_t clock_ticks;
    uint32_t clock_sec;
    MQTTMessage message;

    int btn0 = GPIO_PinInGet(BTN0_PORT, BTN0_PIN) ^ 1;	// make 1 = pressed
    int btn1 = GPIO_PinInGet(BTN1_PORT, BTN1_PIN) ^ 1;	// make 1 = pressed

    clock_ticks = RTCC_CounterGet();
    clock_sec = clock_ticks / 32768;

#if defined(INCLUDE_TEMP_HUMID) && INCLUDE_TEMP_HUMID
    uint32_t humidData = 0;
    int32_t tempDataC = 0;
    int32_t tempDataF;
    readTempHumid(&humidData, &tempDataC);
    tempDataF = ((tempDataC * 9) / 5) + 32000;

    sprintf(buf, "{\"event_data\":{\"device\":\"pearlgecko\",\"iteration\":%u,\"clock\":%u,\"btn0\":%s,\"btn1\":%s,\"tempf\":%d.%d,\"humid\":%u.%u}}",
    		(unsigned int)iteration,
    		(unsigned) clock_sec,
			btn0 ? "true" : "false",
			btn1 ? "true" : "false",
			(int)(tempDataF / 1000),
			(int)(tempDataF % 1000),
			(unsigned)(humidData / 1000),
			(unsigned)(humidData % 1000)
			);
#else
    sprintf(buf, "{\"event_data\":{\"device\":\"pearlgecko\",\"iteration\":%u,\"clock\":%u,\"btn0\":%s,\"btn1\":%s}}",
    		(unsigned int)iteration,
    		(unsigned) clock_sec,
			btn0 ? "true" : "false",
			btn1 ? "true" : "false"
			);
#endif

    message.qos = QOS0;
    message.retained = false;
    message.dup = false;
    message.payload = (void*)buf;
    message.payloadlen = strlen(buf);

    GPIO_PinModeSet(LED0_PORT, LED0_PIN, gpioModePushPull, 1);	// LED0 on

    MQTTPublish(&client, MQTT_TOPIC, &message);

    GPIO_PinModeSet(LED0_PORT, LED0_PIN, gpioModePushPull, 0);	// LED0 off

}

/*****************************************************************************/
static void timer_handler( RTCDRV_TimerID_t id, void *user)
{
    // time to publish.. set the flag and let the main app executes the publish
    publish_now = true;
}

#if 0
/*****************************************************************************/
static void receive_handler(MessageData* rx_msg)
{
    char cmd[2048];

    snprintf(cmd, rx_msg->message->payloadlen + 1, rx_msg->message->payload);
    if(strncmp(cmd, COMMAND_READ_ONCE, strlen(COMMAND_READ_ONCE)) == 0)
    {
        publish_now = true;
    }
    else if(strncmp(cmd, COMMAND_START_PERIODIC, strlen(COMMAND_START_PERIODIC)) == 0)
    {
        RTCDRV_StartTimer(periodic_timer, rtcdrvTimerTypePeriodic, MQTT_PUBLISH_PERIOD, timer_handler, NULL);
        publish_now = true;
    }
    else if(strncmp(cmd, COMMAND_STOP_PERIODIC, strlen(COMMAND_STOP_PERIODIC)) == 0)
    {
        RTCDRV_StopTimer(periodic_timer);
    }
}
#endif

#if defined(INCLUDE_TEMP_HUMID) && INCLUDE_TEMP_HUMID
static void initTempHumid(void)
{
	bool si7013_status = false;

	I2CSPM_Init(&i2cInit);

	/* Enable Si7021 sensor isolation switch */
	/* GPIO clock must have already been enabled */
	GPIO_PinModeSet(gpioPortB, 10, gpioModePushPull, 1);

	/* Get initial sensor status */
	si7013_status = Si7013_Detect(i2cInit.port, SI7021_ADDR, 0);

	if (si7013_status != true) {
		/* Si7021 initialization failed */
	}
}

static void readTempHumid(uint32_t *rhData, int32_t *tData)
{
	Si7013_MeasureRHAndTemp(i2cInit.port, SI7021_ADDR, rhData, tData);
}
#endif

