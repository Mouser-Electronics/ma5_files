
/* Medium One connection parameters */

/* Update these for your own Medium One account */
#define MQTT_USERNAME		""
#define MQTT_PASSWORD		""
#define MQTT_TOPIC			""

/* Broker hostname */
#define MQTT_BROKER			"mqtt.mediumone.com"

/* MQTT client ID */
#define MQTT_CLIENT_ID		"pearlgecko-01"

/* Port number */
#define MQTT_PORT_NON_TLS	61619
